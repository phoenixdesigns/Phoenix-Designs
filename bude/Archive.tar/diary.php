<?php
include 'header.php';
//include '../db_connect.db';
//include 'functions.php';
//add_to_log();
?>
	<div id="diary">
		<h3>Events</h3>
		<table>
		<tr>
		<th class="col_width1">Date</th>
		<th class="col_width2">Time</th>
		<th class="col_width3">Venue</th>
		<th class="col_width2">Price</th>
		<th class="col_width3">Music</th>
		</tr>

		<tr>
		<td class="col_width1">Sat 14th Mar 2009</td>
		<td class="col_width2">8pm</td>
		<td class="col_width3">Parkhouse Centre, Bude</td>
		<td class="col_width2">£10</td>
		<td class="col_width3">Eddy Cochran, Brenda Lee, Buddy Holly, Chuck Berry, Jerry Lee Lewis, Connie Francis & many more!</td>
		</tr>

		<tr>
		<td class="col_width1">Sat 18th Apr 2009</td>
		<td class="col_width2">8pm</td>
		<td class="col_width3">Bullers Arms Hotel, Maramchurch</td>
		<td class="col_width2">£7:50</td>
		<td class="col_width3">The Atlantics + DJ Dynamite Dave</td>
		</tr>

		<tr><td>Sat 30th May 2009</td><td>8pm</td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 15th Aug 2009</td><td>8:30pm</td><td>Parkhouse Centre, Bude</td></tr>
		<tr><td>Sat 10th Oct 2009</td><td>8pm</td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 21st Nov 2009</td><td>8pm</td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 12th Dec 2009</td><td>8pm</td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 13th Feb 2010</td><td>8pm</td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		</table>
	</div>
	<div id="middle-right">
		
	</div>
	<div id="gallery">
		<p>Gallery - Under Construction</p>
	</div>

	<!--<div id="main">
		<p>test</p>
	</div>
	<div id="events">
		<p>Events</p>
	</div>
	<div id="links">
		<p>Links</p>
	</div> -->

<?php
include 'footer.php';
?>