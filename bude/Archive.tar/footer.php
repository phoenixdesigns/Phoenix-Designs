<?php
?>	
	<div id="footer">
		<p>Bude Jive Club<br />
		Liz: 01288 359966 - 07980 513429<br />
		Judith: 01288 353568 - 07815 733185<br />
		<a href="mailto:enquires@budejiveclub.co.uk">email enquires</a></p>
	</div>
</div> <!-- End of container -->
</body>
</html>