<?php
include 'header.php';
//include '../db_connect.db';
//include 'functions.php';
//add_to_log();
?>
	<div id="middle-left">
		<h3>Bude Jive Club</h3>
		<p>Bude Jive Club has been in existence for five years and due to its popularity moved to bigger premises - The Parkhouse Centre, Bude three years ago.  The rise in interest has developed from combining two dance styles, traditional rock and roll and jive.
		<br />
		The Club regularly offers courses of 'beginners and improvers' lessons.  On a regular basis guest instructors give lessons for the 'improvers'.  Rock and rollers who learned to dance in their youth are very welcome at any of the events held by the club.</p>
		<p>Bude Jive Club has fast gained a reputation as a friendly club and has a very varied social diary supported by Rock and Roll club members throughout the southwest.
		<br />
		Throughout the year dances are run with live bands, record hops and other events. The live band nights usually take place at the Bullers Arms, Marhamchurch, near Bude. </p>
	</div>
	<div id="middle-right">
		<h3>Upcoming Events</h3>
		<table>
		<tr><td>Sat 14th Mar 2009 @ 8pm</td><td></td><td>Parkhouse Centre, Bude</td></tr>
		<tr><td>Sat 18th Apr 2009 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 30th May 2009 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 15th Aug 2009 @ 8:30pm</td><td></td><td>Parkhouse Centre, Bude</td></tr>
		<tr><td>Sat 10th Oct 2009 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 21st Nov 2009 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 12th Dec 2009 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		<tr><td>Sat 13th Feb 2010 @ 8pm</td><td></td><td>Bullers Arms Hotel, Maramchurch</td></tr>
		</table>
		<br /><h3>Fancy a Shirt Like This?</h3>
		<img src="images/shirts.jpg" alt="Club Shirts" />
		<h4>Well go online to: 
		<a href="http://www.wagtailsdancewear.co.uk" target="_blank">Wagtails Dance Wear</a></h4>
		<h5>Choose a shirt<br />
		Then fill requirements in back design box<br />
		i.e. Bude Jive Club beneath back logo</h5>
	</div>
	<div id="gallery">
		<p>Gallery - Under Construction</p>
	</div>

	<!--<div id="main">
		<p>test</p>
	</div>
	<div id="events">
		<p>Events</p>
	</div>
	<div id="links">
		<p>Links</p>
	</div> -->

<?php
include 'footer.php';
?>