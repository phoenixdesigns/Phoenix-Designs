<?php
echo('<?xml version="1.0" encoding="utf-8" ?'.'>');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml/DTD/xhtml-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="author" content="Graham Tysall" />
	<meta name="keywords" content="dancing, jive, rock, roll, bude" />
	<meta name="description" content="Bude Jive Club." />
	<meta name="robots" content="all" />
	<title>Bude Jive Club</title>
	<link href="bude.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
<div id="container">
	<div id="top">
		<ul id="navigation">
			<li><a href="./index.php">home</a></li>
			<li><a href="./diary.php">diary</a></li>
		</ul>
		<h1 id="branding">Bude Jive Club
		<blockquote><p>Jiving to live</p></blockquote></h1>
	</div>
<?php
?>